# Extra Data

This data is included for instructors or users to expand their analyses beyond those shown in the case study. 

This data is about **Crude Mortality Rate**  from 1960 to 2018 from the [World Bank](https://data.worldbank.org/indicator/SP.DYN.CDRT.IN) and downloaded from [here](https://data.worldbank.org/indicator/SP.DYN.CDRT.IN). The data is deaths per 1,000 people by country.

The API_SP.DYN.CDRT.IN_DS2_en_excel_v2_804384.xls file shows more details about the data which is within the mortality.csv file.